﻿//{{NO_DEPENDENCIES}}
// Microsoft Visual C++에서 생성한 포함 파일입니다.
// MenuDesign.rc에서 사용되고 있습니다.
//
#define IDD_ABOUTBOX                    100
#define IDR_MAINFRAME                   128
#define IDR_MenuDesignTYPE              130
#define ID_TEST_ITEM1                   32771
#define ID_TEST_ITEM2                   32772
#define ID_TEST_ITEM3                   32773
#define ID_32774                        32774
#define ID_32775                        32775
#define ID_32776                        32776
#define ID_32777                        32777
#define ID_ITEM2_1                      32778
#define ID_ITEM2_2                      32779
#define ID_ITEM2_3                      32780
#define ID_ITEM2_4                      32781
#define ID_MATHFUNC_ABS                 32782
#define ID_MATHFUNC_DIV                 32783
#define ID_MATHFUNC_LOG                 32784
#define ID_MATHFUNC_SIN                 32785
#define ID_MATHFUNC_COS                 32786
#define ID_MATHFUNC_TAN                 32787

// Next default values for new objects
// 
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_NEXT_RESOURCE_VALUE        310
#define _APS_NEXT_COMMAND_VALUE         32788
#define _APS_NEXT_CONTROL_VALUE         1000
#define _APS_NEXT_SYMED_VALUE           310
#endif
#endif
