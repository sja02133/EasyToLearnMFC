﻿//{{NO_DEPENDENCIES}}
// Microsoft Visual C++에서 생성한 포함 파일입니다.
// TrackMouse.rc에서 사용
//
#define IDD_ABOUTBOX				100
#define IDR_MAINFRAME				128
#define IDR_TrackMouseTYPE				130

// 다음은 새 개체에 사용할 기본값입니다.
//
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_NEXT_RESOURCE_VALUE	310
#define _APS_NEXT_CONTROL_VALUE		1000
#define _APS_NEXT_SYMED_VALUE		310
#define _APS_NEXT_COMMAND_VALUE		32771
#endif
#endif
